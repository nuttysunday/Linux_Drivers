"""
Effectively exposes only BTH_1208LS,
due to __all__ in Bluetooth/__init__.py
"""

from .Bluetooth import *
from .Ethernet import *